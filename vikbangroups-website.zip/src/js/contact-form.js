/**
 * contact-form.js — Premium Contact Form Handler
 * Features:
 * - Real-time field validation (WCAG AAA)
 * - Conditional field visibility based on subject
 * - International phone number formatting
 * - Character counter for textarea
 * - Error handling & success confirmation
 * - Chatbot prefill integration
 * - FormSubmit.co email delivery
 */

document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  // FormSubmit.co endpoint
  const FORM_SUBMIT_ENDPOINT = "https://formsubmit.co/vikbangroups@gmail.com";

  // DOM Elements
  const form = document.getElementById("contact-form");
  const nameInput = document.getElementById("contact-name");
  const emailInput = document.getElementById("contact-email");
  const phoneInput = document.getElementById("contact-phone");
  const companyInput = document.getElementById("contact-company");
  const jobtitleInput = document.getElementById("contact-jobtitle");
  const subjectSelect = document.getElementById("contact-subject");
  const budgetSelect = document.getElementById("contact-budget");
  const timelineSelect = document.getElementById("contact-timeline");
  const messageInput = document.getElementById("contact-message");
  const privacyCheckbox = document.getElementById("contact-privacy");
  const submitBtn = document.querySelector(".btn-submit");
  const formMessage = document.getElementById("form-message");

  // Conditional field groups
  const companyGroup = document.getElementById("company-group");
  const jobtitleGroup = document.getElementById("jobtitle-group");
  const budgetTimelineRow = document.getElementById("budget-timeline-row");

  // Safety check
  if (!form) {
    console.warn("Contact form not found");
    return;
  }

  // ========== INITIALIZATION ==========

  // Initialize event listeners
  initializeEventListeners();
  // Prefill from chatbot if available
  prefillFromChatbot();
  // Initial conditional field setup
  updateConditionalFields();

  // ========== EVENT LISTENERS ==========

  function initializeEventListeners() {
    // Real-time validation
    nameInput?.addEventListener("blur", () => validateName());
    emailInput?.addEventListener("blur", () => validateEmail());
    phoneInput?.addEventListener("blur", () => formatPhoneNumber());
    messageInput?.addEventListener("input", () => updateCharCounter());
    messageInput?.addEventListener("blur", () => validateMessage());
    privacyCheckbox?.addEventListener("change", () => validatePrivacy());

    // Subject change - update conditional fields
    subjectSelect?.addEventListener("change", updateConditionalFields);

    // Form submission
    form.addEventListener("submit", handleFormSubmit);
  }

  // ========== CONDITIONAL FIELDS ==========

  function updateConditionalFields() {
    const subject = subjectSelect.value;
    const isB2B =
      subject.includes("Enterprise") ||
      subject.includes("Partnership") ||
      subject.includes("AI Solutions") ||
      subject.includes("Software Development") ||
      subject.includes("Cloud Services");

    // Show/hide company & job title for B2B inquiries
    if (isB2B) {
      companyGroup.style.display = "block";
      jobtitleGroup.style.display = "block";
      budgetTimelineRow.style.display = "grid";
    } else {
      companyGroup.style.display = "none";
      jobtitleGroup.style.display = "none";
      budgetTimelineRow.style.display = "none";
      // Clear values when hidden
      companyInput.value = "";
      jobtitleInput.value = "";
      budgetSelect.value = "";
      timelineSelect.value = "";
    }
  }

  // ========== VALIDATION FUNCTIONS ==========

  function validateName() {
    const value = nameInput.value.trim();
    const errorEl = document.getElementById("error-name");

    if (!value) {
      showFieldError(nameInput, errorEl, "Full name is required");
      return false;
    }

    if (value.length < 2) {
      showFieldError(nameInput, errorEl, "Name must be at least 2 characters");
      return false;
    }

    if (!/^[a-zA-Z\s'-]+$/.test(value)) {
      showFieldError(
        nameInput,
        errorEl,
        "Name can only contain letters, spaces, hyphens, and apostrophes"
      );
      return false;
    }

    clearFieldError(nameInput, errorEl);
    return true;
  }

  function validateEmail() {
    const value = emailInput.value.trim();
    const errorEl = document.getElementById("error-email");

    if (!value) {
      showFieldError(emailInput, errorEl, "Email address is required");
      return false;
    }

    // RFC 5322 simplified regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      showFieldError(emailInput, errorEl, "Please enter a valid email address");
      return false;
    }

    clearFieldError(emailInput, errorEl);
    return true;
  }

  function validatePhone() {
    const value = phoneInput.value.trim();
    const errorEl = document.getElementById("error-phone");

    // Phone is optional, but if provided, must be valid
    if (!value) {
      clearFieldError(phoneInput, errorEl);
      return true;
    }

    // Allow international format: +{country code} {number}
    const phoneRegex = /^[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,9}$/;
    if (!phoneRegex.test(value.replace(/\s/g, ""))) {
      showFieldError(
        phoneInput,
        errorEl,
        "Please enter a valid phone number (e.g., +1 555 123 4567)"
      );
      return false;
    }

    clearFieldError(phoneInput, errorEl);
    return true;
  }

  function validateSubject() {
    const value = subjectSelect.value;
    const errorEl = document.getElementById("error-subject");

    if (!value) {
      showFieldError(subjectSelect, errorEl, "Please select a subject");
      return false;
    }

    clearFieldError(subjectSelect, errorEl);
    return true;
  }

  function validateMessage() {
    const value = messageInput.value.trim();
    const errorEl = document.getElementById("error-message");

    if (!value) {
      showFieldError(messageInput, errorEl, "Message is required");
      return false;
    }

    if (value.length < 10) {
      showFieldError(
        messageInput,
        errorEl,
        "Message must be at least 10 characters"
      );
      return false;
    }

    if (value.length > 500) {
      showFieldError(messageInput, errorEl, "Message cannot exceed 500 characters");
      return false;
    }

    clearFieldError(messageInput, errorEl);
    return true;
  }

  function validatePrivacy() {
    const errorEl = document.getElementById("error-privacy");

    if (!privacyCheckbox.checked) {
      showFieldError(
        privacyCheckbox,
        errorEl,
        "You must agree to the privacy policy"
      );
      return false;
    }

    clearFieldError(privacyCheckbox, errorEl);
    return true;
  }

  // ========== HELPER VALIDATION FUNCTIONS ==========

  function showFieldError(inputEl, errorEl, message) {
    const formGroup = inputEl.closest(".form-group");
    formGroup?.classList.add("error");
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.style.display = "block";
    }
  }

  function clearFieldError(inputEl, errorEl) {
    const formGroup = inputEl.closest(".form-group");
    formGroup?.classList.remove("error");
    if (errorEl) {
      errorEl.textContent = "";
      errorEl.style.display = "none";
    }
  }

  // ========== PHONE NUMBER FORMATTING ==========

  function formatPhoneNumber() {
    let value = phoneInput.value.replace(/\D/g, ""); // Remove non-digits

    if (!value) return;

    // Detect country and format accordingly
    if (value.startsWith("1")) {
      // USA/Canada: +1 (555) 123-4567
      if (value.length >= 10) {
        value = `+1 (${value.slice(1, 4)}) ${value.slice(4, 7)}-${value.slice(7, 11)}`;
      }
    } else if (value.startsWith("91")) {
      // India: +91 98765 43210
      if (value.length >= 12) {
        value = `+91 ${value.slice(2, 7)} ${value.slice(7, 12)}`;
      }
    } else if (value.startsWith("44")) {
      // UK: +44 20 7946 0958
      if (value.length >= 10) {
        value = `+44 ${value.slice(2, 4)} ${value.slice(4)}`;
      }
    } else {
      // Generic international format
      if (value.length > 1) {
        value = `+${value}`;
      }
    }

    phoneInput.value = value;
  }

  // ========== CHARACTER COUNTER ==========

  function updateCharCounter() {
    const charCount = messageInput.value.length;
    const charCounter = document.getElementById("char-count");
    const maxChars = 500;

    if (charCounter) {
      charCounter.textContent = `(${charCount}/${maxChars})`;

      // Color coding
      if (charCount >= maxChars) {
        charCounter.classList.add("critical");
        charCounter.classList.remove("warning");
      } else if (charCount >= maxChars * 0.8) {
        charCounter.classList.add("warning");
        charCounter.classList.remove("critical");
      } else {
        charCounter.classList.remove("warning", "critical");
      }
    }
  }

  // ========== CHATBOT PREFILL ==========

  function prefillFromChatbot() {
    // Check if data exists in sessionStorage from chatbot
    const chatbotName = sessionStorage.getItem("chatbot_name");
    const chatbotPhone = sessionStorage.getItem("chatbot_phone");

    if (chatbotName) {
      nameInput.value = chatbotName;
      nameInput.setAttribute("readonly", "true");
      nameInput.style.backgroundColor = "rgba(39, 174, 96, 0.05)";
    }

    if (chatbotPhone) {
      phoneInput.value = chatbotPhone;
      phoneInput.setAttribute("readonly", "true");
      phoneInput.style.backgroundColor = "rgba(39, 174, 96, 0.05)";
    }
  }

  // ========== FORM SUBMISSION ==========

  async function handleFormSubmit(e) {
    e.preventDefault();

    // Validate all fields
    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isPhoneValid = validatePhone();
    const isSubjectValid = validateSubject();
    const isMessageValid = validateMessage();
    const isPrivacyValid = validatePrivacy();

    // Stop if validation fails
    if (
      !isNameValid ||
      !isEmailValid ||
      !isPhoneValid ||
      !isSubjectValid ||
      !isMessageValid ||
      !isPrivacyValid
    ) {
      showFormMessage(
        "Please fix the errors above and try again.",
        "error"
      );
      return;
    }

    // Disable submit button
    submitBtn.disabled = true;
    const btnText = submitBtn.querySelector(".btn-text");
    const btnLoader = submitBtn.querySelector(".btn-loader");

    if (btnText) btnText.style.display = "none";
    if (btnLoader) btnLoader.style.display = "inline-block";

    // Prepare form data
    const formData = new FormData();
    formData.append("name", nameInput.value.trim());
    formData.append("email", emailInput.value.trim());
    formData.append("phone", phoneInput.value.trim() || "Not provided");
    formData.append("company", companyInput.value.trim() || "Not provided");
    formData.append("jobtitle", jobtitleInput.value.trim() || "Not provided");
    formData.append("subject", subjectSelect.value);
    formData.append("budget", budgetSelect.value || "Not specified");
    formData.append("timeline", timelineSelect.value || "Not specified");
    formData.append("message", messageInput.value.trim());
    formData.append("_captcha", "false");
    formData.append("_template", "table");

    try {
      console.log("📧 Sending contact form...");

      const response = await fetch(FORM_SUBMIT_ENDPOINT, {
        method: "POST",
        body: formData,
      });

      if (response.ok || response.status === 200 || response.type === "opaqueredirect") {
        console.log("✓ Contact form sent successfully");
        showFormMessage(
          "✓ Thank you! Your message has been sent successfully. We'll respond within 24 hours.",
          "success"
        );
        form.reset();
        updateCharCounter();
        updateConditionalFields();
        // Clear sessionStorage
        sessionStorage.removeItem("chatbot_name");
        sessionStorage.removeItem("chatbot_phone");
      } else {
        throw new Error(`Server returned status ${response.status}`);
      }
    } catch (error) {
      console.error("Contact form error:", error);
      showFormMessage(
        "⚠️ Something went wrong. Please try again or contact us directly at info@vikbangroups.com",
        "error"
      );
    } finally {
      // Re-enable submit button
      submitBtn.disabled = false;
      if (btnText) btnText.style.display = "inline";
      if (btnLoader) btnLoader.style.display = "none";
    }
  }

  // ========== FORM MESSAGE DISPLAY ==========

  function showFormMessage(message, type) {
    formMessage.textContent = message;
    formMessage.className = `form-message ${type}`;
    formMessage.style.display = "block";
    formMessage.setAttribute("role", "alert");

    // Scroll to message
    formMessage.scrollIntoView({ behavior: "smooth", block: "nearest" });

    // Auto-hide success message after 6 seconds
    if (type === "success") {
      setTimeout(() => {
        formMessage.style.display = "none";
      }, 6000);
    }
  }

  console.log("✓ Contact form initialized successfully");
});
